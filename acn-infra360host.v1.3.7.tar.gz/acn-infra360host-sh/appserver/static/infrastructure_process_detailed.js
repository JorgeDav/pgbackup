// Translations for en_US

i18n_register({"catalog": {}, "plural": function(n) { return n == 1 ? 0 : 1; }});

require([
		'underscore',
		'jquery',
		'splunkjs/mvc',
		'splunkjs/mvc/tableview',
		'splunkjs/mvc/simplesplunkview',
		'views/shared/results_table/renderers/BaseCellRenderer',
		'splunkjs/mvc/simplexml/ready!'
		],

		function(_, $, mvc, TableView, SimpleSplunkView, BaseCellRenderer) {
				//alert("running"); // Check if this script is being used
				var CustomIconRenderer = TableView.BaseCellRenderer.extend({
						canRender: function(cell) {
								return (cell.field === "Process Status" ||
										cell.field === "Latest Elapsed Time" ||
										cell.field === "Latest Process ID" ||
										cell.field === "Latest % Processor Time" ||
										cell.field === "Latest Pool Nonpaged GB" ||
										cell.field === "Latest Pool Paged GB" ||
										cell.field === "Latest Private GB" ||
										cell.field === "Latest Thread Count"
								       );
						},
						render: function($td, cell) {
								var cell_value
								var status;
								var label;
								var icon;

								cell_value = cell.value;
								status = cell.value.split(":")[0];
								label = cell.value.split(":")[1];

								if (status == 5) {
										icon = 'status-severe';
								}
								else if (status == 3) {
										icon = 'status-elevated';
								}
								else if (status == 1) {
										icon = 'status-low';
								}
								else {
										icon = 'status-none';
								}

								$td.addClass('icon-inline').html(_.template('<i class="icon-<%-icon%>"></i><%- text %>', {
										icon: icon,
										text: label
								}));
						}
				});
				mvc.Components.get('host_summary_table').getVisualization(function(tableView) {
						// Register custom cell renderer
						tableView.table.addCellRenderer(new CustomIconRenderer());
						// Force the table to re-render
						tableView.table.render();
																});
		});
