# ACN Monitoring Infrastructure UI - Configuration Guide #

## Contents ##
1. Introduction
2. Setup
	1. System Requirements
	2. Splunk Apps
		1. Required
		2. Optional
	3. Universal Forwarder Apps
		1. Required
		2. Optional
	4. Optional UF Apps
3. Required Configuration Items
4. Optional Configuration Items
5. Exceptions to design standard

## 1. Introduction ##

The **acn-infrastructure360-sh** app holds all the indexes used for infrastructure monitoring and analytics.
It provides analytics on server performance (ie: cpu usage, memory usage, storage usage, processes runtime, etc.) per server.
Note that this app has a complement data app, **acn-infrastructure360-data**.


## 2. Setup ##

### 2.1 System Requirements ###

The following preconditions must apply in order for the **acn-infrastructure360-sh** app to function correctly:
* The servers hosting the UF Apps are running the following operating systems:
	* **Linux** (Enterprise 6 or 7)
	* **Windows** (2008 or 2012)
* Splunk is installed.
* Splunk Universal Forwarder is installed on servers to be monitored. 
* The correct ports and firewall permissions have been set to allow for forwarding of data.


### 2.2 Splunk Apps ###

#### 2.2.1 Required Splunk Apps ####

This app must be deployed alongside the following Splunk apps in order to function correctly:

| App Name                            | Innersource Link                                                                                  | Description                                                                                                                                                                                                                        |
|-------------------------------------|---------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| acn-infrastructure360-data | https://innersource.accenture.com/projects/A1220/repos/acn-infrastructure360-data/browse | The ACN Infrastructure Monitoring app provides monitoring for system infrastructure. This is the data component of the ACN Infrastructure Monitoring app and contains all the Splunk knowledge objects for the Splunk indexer.   |
| acn-monitoring-common-ui           | https://innersource.accenture.com/projects/A1220/repos/acn-monitoring-common-ui/browse           | The ACN Monitoring Common app contains supporting files used by multiple other applications. This is the UI component of the ACN Monitoring Common app and contains all the Splunk knowledge objects for the Splunk search head. |
| acn-monitoring-common-data         | https://innersource.accenture.com/projects/A1220/repos/acn-monitoring-common-data/browse         | The ACN Monitoring Common app contains supporting files used by multiple other applications. This is the data component of the ACN Monitoring Common app and contains all the Splunk knowledge objects for the Splunk indexer.   |

This app also requires particular knowledge objects to be configured. See section "2.2. Required Configuration Items" for more details.


#### 2.2.2 Optional Splunk Apps ####

These apps can be deployed to Splunk to provide additional functionality:

| App Name                     | Innersource Link                                                                           | Description                                                                                                                                                                          |
|------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| acn-alertcentre360-data | https://innersource.accenture.com/projects/A1220/repos/acn-alertcentre360-data/browse | The ACN Alerting Framework app is an add-on used to enable email alerting. This is the data component of the app and contains all the knowledge objects for the Splunk indexer.     |
| acn-alertcentre360-ui   | https://innersource.accenture.com/projects/A1220/repos/acn-alertcentre360-data/browse | The ACN Alerting Framework app is an add-on used to enable email alerting. This is the data component of the app and contains all the knowledge objects for the Splunk search head. |


### 2.3 UF Apps ###

#### 2.4 Required UF Apps ####

The following UF apps must be deployed in order for this app to function correctly:

* For Windows:
	* Splunk_TA_windows_ACN_Monitoring_UF
* For Linux:
	* acn_splunk_ta_linux_json

Each of the UF apps can be found within the directory **acn-infrastructure360-data/appserver/addons/**.
See the **aam-monitoring-infrastructure-data/README.md** for details.


#### 2.4 Optional UF Apps ####

The following apps can be deployed to allow for monitoring additional fields:
* For Windows:
	* acn-monitoring-infra-windows-server-information-uf
	* acn-monitoring-infrastructure-windows-getdateformat-uf
	* Splunk_TA_windows_ACN_Monitoring_SQL_Database_UF
* For Linux:
	* acn-monitoring-infra-linux-server-information-uf

Each of the UF apps can be found within the directory **acn-infrastructure360-data/appserver/addons/**.
See the **acn-infrastructure360-data/README.md** for details.


## 3. Required Configuration Items ##

The following items need to be configured in order for the apps to function correctly:

1. Lookup Tables
	1. lookup_fields_information_os_monitoring.csv
2. Eventtype whitelists
	1. et_whitelist_datamodel_os_monitoring_tier1
	2. et_whitelist_datamodel_os_monitoring_tier2
	3. et_whitelist_datamodel_db_perfmon_monitoring_database_replication_tier1


### 3.1 Lookup Tables ###

#### 3.1.1 lookup_fields_information_os_monitoring.csv ####

The **lookup_fields_information_os_monitoring.csv** is a lookup table which holds informational fields used to:
* logically group metrics together under **tower**s.
* determine the statistical analytics Splunk will perform on the metric using the field **field_stats**.

The lookup table has the following fields:

| Field Name  | Lookup Use | Description                                                                                                                                                                                                                                                |
|-------------|------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| object      | Input      | The "object" group which the "counter" belongs to. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that "object" is appended with "counter" to form the metrics display name field "metric_label". |
| counter     | Input      | The name of the metric. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that "counter" is appended with "object" to form the metrics display name field "metric_label".                            |
| field_stats | Output     | The stats function which Splunk will use to perform analytics on the field. The function must to be supported by data models in order to work.                                                                                                             |
| tower       | Output     | A collection of metrics.                                                                                                                                                                                                                                   |

### 3.2 Eventtype whitelists ###

#### 3.2.1 et_whitelist_datamodel_os_monitoring_tier1 ####

The **et_whitelist_datamodel_os_monitoring_tier1** is an eventtype which is used to whitelist fields from the tier1 index that will have analytics performed on them. The analytics are performed using the datamodel **ACN OS Monitoring** and are seperated by **host**.
This is done by filtering to only search for specific fields in the **ACN OS Monitoring** data model. A shorter list will result in the data model performing faster.
The best practice for filering using the eventype is to search for specific combinations of **counter**, **object** and **instance**.


#### 3.2.2 et_whitelist_datamodel_os_monitoring_tier2 ####

The **et_whitelist_datamodel_os_monitoring_tier2** is an eventtype which is used to whitelist fields from the tier2 index that will have analytics performed on them. The analytics are performed using the datamodel **ACN OS Monitoring** and are seperated by **host**.
This is done by filtering to only search for specific fields in the **ACN OS Monitoring** data model. A shorter list will result in the data model performing faster.
The best practice for filering using the eventype is to search for eventtypes which refer to **tier2 save search sources**.


#### 3.2.3 et_whitelist_datamodel_db_perfmon_monitoring_database_replication_tier1 ####

This eventtype whitelist functions the same way as **et_whitelist_datamodel_os_monitoring_tier1**. However, the analytics performed on this whitelist are seperated by **cluster**.


## 4. Optional Configuration Items ##

The following items can to be configured in order to enhance the analytics of the app:

1. Static Lists
	1. Database Lookup Tables
		1. lookup_static_list_database.csv
		2. lookup_static_list_database_fields.csv
	2. Process Lookup Tables
		1. lookup_static_list_process.csv
		2. lookup_static_list_process_fields.csv
	3. Storage Lookup Tables
		1. lookup_static_list_storage_mount.csv
		2. lookup_static_list_storage_mount_fields.csv
2. Metric Thresholds Lookup Tables
	1. lookup_automated_thresholds_os_monitoring.csv
	2. lookup_manual_thresholds_override_os_monitoring.csv
3. Datamodel Lookups Tables
	1. lookup_blacklist_datamodel_fields_os_monitoring.csv
4. Additional Metrics Lookup Tables
	1. lookup_operating_system_list.csv
	2. lookup_whitelist_process_restart.csv


### 4.1 Static Lists ###

The static list lookup tables are used to define hosts and metrics which are expected to continueously send data to Splunk at regular intervals. If data stops sending to Splunk and the host and metric are included in the lookup, then the metric will alert as a critical issue (red). If no static list is required, the entire lookup table can be cleared with the exception of the headers.

These lookup tables come in pairs, **lookup_static_list_[FUNCTION].csv** and **lookup_static_list_[FUNCTION]\_fields.csv**. The two lookup tables work together to generate the static list. The lookups are:


| Lookup Name                               | Description                                                                                                                                                                                                                                                                                                   |
|-------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| lookup_static_list_[FUNCTION].csv         | Used to list the combinations of hosts and instances required. Each line item should be a **unique combination of host and instance**.                                                                                                                                                                        |
| lookup_static_list_[FUNCTION]\_fields.csv | Used to define the metrics which are required. This lookup joins to the **lookup_static_list_[FUNCTION].csv** lookup to generate the static list. Each line item should be a **unique combination of contract_type, system, sub_system, environment, type, host, instance, object, counter and field_stats**. |


The lookup files have the following fields, of which some are critical fields used in the alerting application and displayed on the dashboards :

**lookup_static_list_[FUNCTION].csv**

| Field Name      | Lookup Use | Description                                                                                                                                                                                                                                                                                             |
|-----------------|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| host            | Output     | Name of host forwarding data to Splunk.                                                                                                                                                                                                                                                                 |
| instance        | Output     | Name of the instance. A single host can have many instances.                                                                                                                                                                                                                                            |
| enabled         | Output     | Allows for enabling or disabling specific lines from the static list. Value can be 1 (enabled) or 0 (disabled).                                                                                                                                                                                         |
| expected_status | Output     | Special field used to set the alert_value output of the static list to either 1 (green) or 5 (red). Values can be 1 (5, red) or 0 (1, green). This is currently only used in the **lookup_static_list_process.csv** to mark processes which should have an alert level set to green when they are down. |


**lookup_static_list_[FUNCTION]\_fields.csv**

| Field Name    | Lookup Use   | Wildcard | Description                                                                                                                                                                                                                                                                                                                                                                           |
|---------------|--------------|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| contract_type | None         | Yes      | Name of the contract type of the server. This field is purely informational.                                                                                                                                                                                                                                                                                                          |
| system        | Input        | Yes      | Name of the system the server belongs to.                                                                                                                                                                                                                                                                                                                                             |
| sub_system    | Input        | Yes      | The subgroup a system belongs to within a system.                                                                                                                                                                                                                                                                                                                                     |
| environment   | Input        | Yes      | The environment a host belongs to ie: DEV, TEST, PROD.                                                                                                                                                                                                                                                                                                                                |
| type          | Input        | Yes      | Server type. ie: databases, application, web.                                                                                                                                                                                                                                                                                                                                          |
| host          | Input        | Yes      | Name of the server. Maps to the name of host forwarding data to Splunk. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                                                                                                                                                                                            |
| object        | Input/Output | No       | The **object** group a **counter** belongs to. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **object** is appended with **counter** to form the metrics display name field **metric_label**. When used together, the **host, instance, object and counter should form a unique combination** within the lookup. |
| counter       | Input/Output | No       | The name of the metric. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **counter** is appended with **object** to form the metrics display name field **metric_label**. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                        |
| tower         | Output       | No       | The name used to group together a collection of metrics.                                                                                                                                                                                                                                                                                                                              |
| metric_unit   | Output       | No       | The units used to describe the fields value. For windows perfmon data, this is default set to the counter name.                                                                                                                                                                                                                                                                       |
| field_stats   | Output       | No       | The stats function which Splunk will use to perform analytics on the field. The function must to be supported by data models in order to work.                                                                                                                                                                                                                                        |
| instance      | Input        | Yes      | Name of the instance. A single host can have many instances. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                                                                                                                                                                                                       |


### 4.2 Metric Thresholds ###

There are two lookup tables used for setting thresholds. They are:

| Lookup Name                                         | Description                                                                                                                                                                                                                                                                                                                           |
|-----------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| lookup_automated_thresholds_os_monitoring.csv       | This lookup automatically generates with threshold values for each **host, object, counter and instance** based on previously indexed data. Therefore, the CSV will only generate with meaningful data 30 minutes after first deploying this app.  There is a **manual action required to move the CSV file into the lookup folder.** |
| lookup_manual_thresholds_override_os_monitoring.csv | Values in this lookup will override threshold values from the **lookup_automated_thresholds_os_monitoring** lookup. Both files are configured in the same way. If manual thresholds are not required, the lookup can be left empty (with the exception of the headers).                                                               |


#### 4.2.1 lookup_automated_thresholds_os_monitoring.csv ####

| Field Name  | Lookup Use | Wildcard | Description                                                                                                                                                                                                                                                                                                                                                                                   |
|-------------|------------|----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| object      | Input      | No       | The **object** group a **counter** belongs to. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **object** is appended with **counter** to form the metrics display name field **metric_label**. When used together, the **source_host, instance, object and counter should form a unique combination** within the lookup.  |
| counter     | Input      | No       | The name of the metric. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **counter** is appended with **object** to form the metrics display name field **metric_label**. When used together, the **source_host, instance, object and counter should form a unique combination** within the lookup.                         |
| source_host | Input      | Yes      | Name of the server. Maps to the name of host forwarding data to Splunk. When used together, the **source_host, instance, object and counter should form a unique combination** within the lookup.                                                                                                                                                                                             |
| instance    | Input      | Yes      | Name of the instance. A single source_host can have many instances. When used together, the source_host, instance, object and counter should form a unique combination within the lookup.                                                                                                                                                                                                     |
| threshold1  | Output     | No       | The lower bounds for field metric thresholds value. The value must be numeric. Values less than threshold1 report an alert_value of 5 (red).                                                                                                                                                                                                                                                  |
| threshold2  | Output     | No       | The middle lower bounds for field metric thresholds value. The value must be numeric. Values between threshold1 and threshold2 report an alert_value of 3 (yellow).                                                                                                                                                                                                                           |
| threshold3  | Output     | No       | The middle upper bounds for field metric thresholds value. The value must be numeric. Values between threshold2 and threshold3 report an alert_value of 1 (green).                                                                                                                                                                                                                            |
| threshold4  | Output     | No       | The upper bounds for field metric thresholds value. The value must be numeric. Values between threshold3 and threshold4 report an alert_value of 3 (yellow). Values greater than threshold4 report an alert_value of 4 (red).                                                                                                                                                                 |


#### 4.2.2 lookup_manual_thresholds_override_os_monitoring.csv ####

| Field Name           | Lookup Use | Wildcard | Description                                                                                                                                                                                                                                                                                                                                                                           |
|----------------------|------------|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| host                 | Input      | Yes      | Name of the server. Maps to the name of host forwarding data to Splunk. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                                                                                                                                                                                            |
| system               | Input      | Yes      | Name of the system the server belongs to.                                                                                                                                                                                                                                                                                                                                             |
| sub_system           | Input      | Yes      | The subgroup a system belongs to within a system.                                                                                                                                                                                                                                                                                                                                     |
| environment          | Input      | Yes      | The environment a host belongs to ie: DEV, TEST, PROD.                                                                                                                                                                                                                                                                                                                                |
| type                 | Input      | Yes      | Server type. ie: databases, application, web.                                                                                                                                                                                                                                                                                                                                         |
| contract_type        | None       | Yes      | Name of the contract type of the server. This field is purely informational.                                                                                                                                                                                                                                                                                                          |
| object               | Input      | No       | The **object** group a **counter** belongs to. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **object** is appended with **counter** to form the metrics display name field **metric_label**. When used together, the **host, instance, object and counter should form a unique combination** within the lookup. |
| counter              | Input      | No       | The name of the metric. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **counter** is appended with **object** to form the metrics display name field **metric_label**. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                        |
| field_stats          | Input      | Yes      | The stats function which Splunk will use to perform analytics on the field. The function must to be supported by data models in order to work.                                                                                                                                                                                                                                        |
| instance             | Input      | Yes      | Name of the instance. A single host can have many instances. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                                                                                                                                                                                                       |
| manual_threshold1    | Output     | No       | The lower bounds for field metric thresholds value. The value must be numeric. Overrides the automated thresholds. Values less than threshold1 report an alert_value of 5 (red).                                                                                                                                                                                                      |
| manual_threshold2    | Output     | No       | The middle lower bounds for field metric thresholds value. The value must be numeric. Overrides the automated thresholds. Values between threshold1 and threshold2 report an alert_value of 3 (yellow).                                                                                                                                                                               |
| manual_threshold3    | Output     | No       | The middle upper bounds for field metric thresholds value. The value must be numeric. Overrides the automated thresholds. Values between threshold2 and threshold3 report an alert_value of 1 (green).                                                                                                                                                                                |
| manual_threshold4    | Output     | No       | The upper bounds for field metric thresholds value. The value must be numeric. Overrides the automated thresholds. Values between threshold3 and threshold4 report an alert_value of 3 (yellow). Values greater than threshold4 report an alert_value of 4 (red).                                                                                                                     |
| use_manual_threshold | Output     | No       | Enable or disable the manual threshold line item. Can be a value of 1 (thresholds on) or 0 (thresholds off). The automated threshold CSV file will not generate values for items which have manual_thresholds enabled.                                                                                                                                                                |


### 4.3 Datamodel Lookups ###

#### 4.3.1 lookup_blacklist_datamodel_fields_os_monitoring.csv ####

This lookup table is used to **blacklist any combination of host, system, sub_system, environment, objet, counter and/or instance** from alerting.

| Field Name    | Lookup Use   | Wildcard | Description                                                                                                                                                                                                                                                                                                                                                                           |
|---------------|--------------|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| host          | Input        | Yes      | Name of the server. Maps to the name of host forwarding data to Splunk. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                                                                                                                                                                                            |
| system        | Input        | Yes      | Name of the system the server belongs to.                                                                                                                                                                                                                                                                                                                                             |
| sub_system    | Input        | Yes      | The subgroup a system belongs to within a system.                                                                                                                                                                                                                                                                                                                                     |
| environment   | Input        | Yes      | The environment a host belongs to ie: DEV, TEST, PROD.                                                                                                                                                                                                                                                                                                                                |
| type          | Input        | Yes      | Server type. ie: databases, application, web.                                                                                                                                                                                                                                                                                                                                         |
| contract_type | None         | Yes      | Name of the contract type of the server. This field is purely informational.                                                                                                                                                                                                                                                                                                          |
| object        | Input/Output | Yes      | The **object** group a **counter** belongs to. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **object** is appended with **counter** to form the metrics display name field **metric_label**. When used together, the **host, instance, object and counter should form a unique combination** within the lookup. |
| counter       | Input/Output | Yes      | The name of the metric. This field is used as a input for the lookup table and matches with data in the tier1 and tier2 indexes. Note that **counter** is appended with **object** to form the metrics display name field **metric_label**. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                        |
| instance      | Input        | Yes      | Name of the instance. A single host can have many instances. When used together, the **host, instance, object and counter should form a unique combination** within the lookup.                                                                                                                                                                                                       |
| blacklist     | Output       | No       | Used to blacklist events from being alerted on. The field can be two values, enabled (1) or disabled (0).                                                                                                                                                                                                                                                                             |


### 4.4 Additional Metrics ###

#### 4.4.1 lookup_operating_system_list.csv ####

| Field Name                  | Lookup Use | Wildcard | Description                                                                                      |
|-----------------------------|------------|----------|--------------------------------------------------------------------------------------------------|
| full_name_operating_system  | Input      | Yes      | The official operating system title and version. Should only be Windows of Linux CentOS version. |
| short_name_operating_system | Output     | No       | Short name. Windows or Linux.                                                                    |


#### 4.4.2 lookup_whitelist_process_restart.csv ####

CSV HAS BEEN REMOVED... ITS NOW A EVENTTYPE

## 5.0 Design Exceptions  ##

1. The save search search_update_acn_infra_delta_roc_tier2 has a delay of 1 minute in comparision to all other data. This is a constraint of the calculation used.
2. The save search search_update_acn_infra_delta_roc_tier2 must read data which is indexed every 10 seconds.
