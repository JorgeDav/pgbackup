Only one UF app should be deployed.  
The UF apps have the same data just in different format.

The Linux Redhat and CentOS UF apps can be found in the rhel_2.6_3.10 directory and either of them can be deployed. They are:
1. acn-monitoring-infra-linux-monitoring-json-uf = json formatted data
2. acn-monitoring-infra-linux-monitoring-kv-uf = key value pair formatted data

The Windows UF apps can be found in the win_x86_64 directory and either of them can be deployed. They are:
1. Splunk_TA_windows_ACN_Monitoring_SQL_Database_UF
2. Splunk_TA_windows_ACN_Monitoring_UF

The default interval for each object in this UF application are:
        - CPU: 10 Secs
        - Paging File: 10 Secs
        - Memory: 10 Secs
        - LogicalDisk: 60 Secs
        - PhysicalDisk: 60 Secs
        - IPv4: 60 Secs
        - TCPv4: 10 Secs
        - Network Interface: 10 Secs
        - System: 60 Secs
        - Operating System(Total Physical Memory): 60 Secs


The following versions of RHEL are supported:
| RHEL Version  | Supporting App Folder  |
|---|---|
| 5.11  | rhel_5.11  |
| 6.x  | rhel_6.x  |

Note: RHEL 7.x is currently not supported but UFs supporting RHEL 6.x have successfully been used to monitor RHEL 7.x instances.
