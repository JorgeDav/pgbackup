###########################################################################
### Accenture Advance Technology  Architecture - Operation Architecture
### Accenture myWizard Analytics for Application Management (ACN)
### Website: aiam.accenture.com
### Contact: Alvin Sulendra
### Email: alvin.sulendra@accenture.com
###########################################################################

ACN Custom configuration for ACN-Monitoring-Infrastructure, local/inputs.conf, of Splunk [NAME OF UF APP] v[4.8.0]
	- Expected Licence usage requirements: ~120MB per host per day

Default interval for each object in this UF application is:
	- CPU: 10 Secs
	- Paging File: 10 Secs
	- Memory: 10 Secs
	- LogicalDisk: 60 Secs
	- PhysicalDisk: 60 Secs
	- IPv4: 60 Secs
	- TCPv4: 10 Secs
	- Network Interface: 10 Secs
	- System: 60 Secs
	- Operating System(Total Physical Memory): 60 Secs
	- Processor: 300 Secs
	- Computer: 1 Day
