The there's currently no difference between the UF and HF of the Windows app
