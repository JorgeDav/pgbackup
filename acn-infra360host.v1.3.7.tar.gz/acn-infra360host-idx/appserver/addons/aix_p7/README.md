THE HF has not yet been tested for the AIX application
