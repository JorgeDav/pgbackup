As of 15:34 25-07-2018, the UF acn-monitoring-infra-linux-monitoring-kv-uf is exactly the same as RHEL 6 and 7 with the exception of 3 scripts:
1. kv_paging_file_percentage_usage.sh = totally different script due to underlying command not working in EL5
2. kv_network_bytes_received_per_sec.sh = Units are different. This uses bytes whereas EL6 and 7 use kbytes.
3. kv_network_bytes_sent_per_sec.sh = Units are different. This uses bytes whereas EL6 and 7 use kbytes.
