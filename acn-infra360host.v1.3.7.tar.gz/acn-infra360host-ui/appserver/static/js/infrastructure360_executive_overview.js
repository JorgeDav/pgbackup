// INFRASTRUCTURE OVERVIEW DRILL DOWN
require([
    'underscore',
    'jquery',
    'splunkjs/mvc',
], function (_, $, mvc) {

    // LIGHTBOX EXIT BUTTON
    $('#tooltip').click(function () {
        if ($(event.target).attr('id') == 'tooltip') {
            setToken('source_host_trends_token', undefined);
            $('.view-mode #tooltip').fadeOut(250);
        }
    });

    // LIGHTBOX VIEW BUTTON
    $('#infra_overview_panel').on('click', 'table > tbody > tr > td > a', function () {
        let hostname, instance, type, lightbox;
        type = $(this).closest('td').attr('type');
        hostname = $(this).closest('tr').children('td[type=HOST]').html();
        instance = $(this).closest('tr').children('td[type=INSTANCE]').html();

        switch (type) {
            case 'CPU':
            case 'PROCESSOR_PROCESSOR_TIME_ALERT':
                type = 'Processor : % Processor Time Alert';
                break;
            case 'CPU_15M_AVG':
            case 'CPU_LOAD_AVERAGE_15':
                type = 'Processor : CPU Load Average 15 Alert';
                break;
            case 'MEMORY':
                type = 'Memory : % Used Memory Alert';
                break;
            case 'DISK':
                type = 'LogicalDisk : % Space Used Alert';
                instance = $(this).closest('tr').children('td[type=DISK]').children('a').html().split('(')[1].split(')')[0];
                break;
            case 'SPACE_USED':
                type = 'LogicalDisk : % Space Used Alert';
                break;
            case 'HOST_ONLINE':
                type = 'Host reporting no data';
                break;
            case 'HOST_UP_TIME':
                type = 'System : System Up Time Alert';
                break;
            case 'CONN_FAILURES':
                type = 'TCPv4 : Connection Failures Alert';
                break;
            case 'CONN_FAILURES_ROC':
                type = 'TCPv4 : Connection Failures Delta ROC Alert';
                break;
            case 'CONN_ACTIVE':
                type = 'TCPv4 : Connections Active Alert';
                break;
            case 'CONN_ACTIVE_ROC':
                type = 'TCPv4 : Connections Active Delta ROC Alert';
                break;
            case 'CONN_RESET':
                type = 'TCPv4 : Connections Reset Alert';
                break;
            case 'CONN_RESET_ROC':
                type = 'TCPv4 : Connections Reset Delta ROC Alert';
                break;
            case 'DATAGRAMS_RECEIVED_ADDRESS_ERRORS':
                type = 'IPv4 : Datagrams Received Address Errors Alert';
                break;
            case 'AVG_DISK_READ_QUEUE_LENGTH':
                type = 'PhysicalDisk : Avg. Disk Read Queue Length Alert';
                break;
            case 'AVG_DISK_WRITE_QUEUE_LENGTH':
                type = 'PhysicalDisk : Avg. Disk Write Queue Length Alert';
                break;
            case 'AVG_DISK_SEC_READ':
                type = 'PhysicalDisk : Avg. Disk sec/Read Alert';
                break;
            case 'AVG_DISK_SEC_WRITE':
                type = 'PhysicalDisk : Avg. Disk sec/Write Alert';
                break;
            case 'AVG_DISK_QUEUE_LENGTH':
                type = 'PhysicalDisk : Avg. Disk Queue Length Alert';
                break;
            case 'AVG_DISK_SEC_TRANSFER':
                type = 'PhysicalDisk : Avg. Disk sec/Transfer Alert';
                break;
            case 'DISK_TRANSFERS_SEC':
                type = 'PhysicalDisk : Disk Transfers/sec Alert';
                break;
            case 'SWAP':
                type = 'Paging File : % Usage Alert';
                instance = $(this).closest('tr').children('td[type=SWAP_INSTANCE]').html();
                break;
            case 'USED_MEMORY':
                type = 'Memory : % Used Memory Alert';
                instance = $(this).closest('tr').children('td[type=MEMORY_INSTANCE]').html();
                break;
            case 'AVAILABLE_GIGABYTES':
                type = 'Memory : Available Gigabytes Alert';
                instance = $(this).closest('tr').children('td[type=MEMORY_INSTANCE]').html();
                break;
        }

        if (instance === undefined) {
            instance = '*';
        }

        setToken('source_host_trends_token', hostname);
        setToken('instance_trends_token', instance);
        setToken('metric_label_trends_token', type);
        $('.view-mode #tooltip').fadeIn(250);
    });

    // SET TOKEN
    function setToken(name, value) {
        var defaultTokenModel = mvc.Components.get('default');
        var submittedTokenModel = mvc.Components.get('submitted');
        defaultTokenModel.set(name, value);
        submittedTokenModel.set(name, value);
    }

});
