require([
    'underscore',
    'jquery',
    'splunkjs/mvc',
    'splunkjs/mvc/tableview',
    'splunkjs/mvc/simplexml/ready!'
    ],
    function(_, $, mvc, TableView) {
        var CustomIconRenderer = TableView.BaseCellRenderer.extend({
            canRender: function(cell) {
                return cell.field
            },
            render: function($td, cell) {
                var array, indicator, text, icon, color;
                array = cell.value.split(':::');
    
                if (array.length === 1) {
                    text = array[0];
                    $td.html(_.template("<%-text%>", {
                        text: text
                    }));
                } else {
                    indicator = array[0].toLowerCase();
                    text = array[1];
                    switch (indicator) {
                        case '1':
                            icon = 'fa fa-check fa-2x';
                            color = '#50b71d';
                            break;
                        case '2':
                            icon = 'fa fa-info fa-2x';
                            color = '#02abee';
                            break;
                        case '3':
                            icon = 'fa fa-exclamation-triangle fa-2x';
                            color = '#f1ab02';
                            break;
                        case '5':
                            icon = 'fa fa-times fa-2x';
                            color = '#e35502';
                            break;
                    }
                    $td.html(_.template("<h1><i class='<%-icon%>' aria-hidden='true' style='color:<%-color%>;width: auto;'></i><%-text%></h1>", {
                        icon: icon,
                        color: color,
                        text: text
                    }));
                }
            }
        });
        var panels = [
            'single_cpu_load_average_15',
            'single_processor_time',
            'single_used_memory',
            'single_swap',
            'single_space_used'
        ]
        for (var i = 0; i < panels.length; i++) {
            try {
                var component = mvc.Components.get(panels[i]);
                if (component) {
                    component.getVisualization(function(tableView) {
                        tableView.table.addCellRenderer(new CustomIconRenderer());
                        tableView.table.render();
                    });
                }
            } catch (err) {
            }
        }

    }
);