// INFRASTRUCTURE OVERVIEW CELL RENDERER
require([
    'underscore',
    'jquery',
    'splunkjs/mvc',
    'splunkjs/mvc/tableview',
    'views/shared/results_table/renderers/BaseCellRenderer',
    'splunkjs/mvc/simplexml/ready!'
], function (_, $, mvc, TableView, BaseCellRenderer) {


    // INFRASTRUCTURE OVERVIEW PANEL ICONS
    var CustomInfraIconRenderer = TableView.BaseCellRenderer.extend({
        canRender: function (cell) {
            return cell.field;
        },
        render: function ($td, cell) {
            var array, type, indicator, text, icon, color;
            array = cell.value.split(':::');

            type = cell.field.replace(/[^A-Z0-9]+/ig, "_").replace(/^_+|_+$/g, '').toUpperCase();
            $td.attr('type', type);

            if (array.length === 1) {
                text = array[0];
                $td.html(_.template("<%-text%>", {
                    text: text
                }));
            } else {
                indicator = array[0].toLowerCase();
                text = array[1];
                switch (indicator) {
                    case '1':
                        icon = 'fa fa-check';
                        color = '#50b71d';
                        break;
                    case '2':
                        icon = 'fa fa-info';
                        color = '#02abee';
                        break;
                    case '3':
                        icon = 'fa fa-exclamation-triangle';
                        color = '#f1ab02';
                        break;
                    case '5':
                        icon = 'fa fa-times';
                        color = '#e35502';
                        break;
                }
                $td.html(_.template("<i class='<%-icon%>' aria-hidden='true' style='color:<%-color%>'></i> <a><%-text%></a>", {
                    icon: icon,
                    color: color,
                    text: text
                }));
            }
        }
    });
    var infraPanels = [
        'infra_detail_table',
        'infra_cpu_detail_table',
        'infra_memory_detail_table',
        'infra_network_detail_table',
        'infra_physical_detail_table',
        'infra_logical_detail_table'
    ];
    for (var i = 0; i < infraPanels.length; i++) {
        try {
            var component = mvc.Components.get(infraPanels[i]);
            if (component) {
                component.getVisualization(function (tableView) {
                    tableView.table.addCellRenderer(new CustomInfraIconRenderer());
                    tableView.table.render();
                });
            }
        } catch (err) {}
    }

});
