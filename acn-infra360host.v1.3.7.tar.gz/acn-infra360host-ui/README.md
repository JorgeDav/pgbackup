# ACN myWizard 360 Infrastructure - Configuration Guide #

## Contents ##
1. Introduction
2. Setup
	1. System Requirements
	2. Splunk Apps
		1. Required Splunk Apps
3. Constraints


## 1. Introduction ##

The **myWizard 360 Infrastructure** app holds all the dashboards used for infrastructure monitoring and analytics.
It provides analytics on server performance (ie: cpu usage, memory usage, storage usage, processes runtime, etc.) per server.
Note that this app requires the two other apps to operate, the **acn-infrastructure360-data** and **acn-infrastructure360-sh**.


## 2. Setup ##

### 2.1 System Requirements ###

The following preconditions must apply in order for the **myWizard 360 Infrastructure** app to function correctly:
* The servers hosting the UF Apps are running the following operating systems:
        * **Linux** (Enterprise 6 or 7)
        * **Windows** (2008 or 2012)
* Splunk is installed.
* Splunk Universal Forwarder is installed on servers to be monitored.
* The correct ports and firewall permissions have been set to allow for forwarding of data.


### 2.2 Splunk Apps ###

#### 2.2.1 Required Splunk Apps ####

This app must be deployed alongside the following Splunk apps in order to function correctly:

| App Name                            | Innersource Link                                                                                  | Description                                                                                                                                                                                                                        |
|-------------------------------------|---------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| acn-infrastructure360-data | https://innersource.accenture.com/projects/A1220/repos/acn-infrastructure360-data/browse | The ACN Infrastructure Monitoring app provides monitoring for system infrastructure. This is the data component of the ACN Infrastructure Monitoring app and contains all the Splunk knowledge objects for the Splunk indexer.   |
| acn-monitoring-common-ui           | https://innersource.accenture.com/projects/A1220/repos/acn-monitoring-common-ui/browse           | The ACN Monitoring Common app contains supporting files used by multiple other applications. This is the UI component of the ACN Monitoring Common app and contains all the Splunk knowledge objects for the Splunk search head. |
| acn-monitoring-common-data         | https://innersource.accenture.com/projects/A1220/repos/acn-monitoring-common-data/browse         | The ACN Monitoring Common app contains supporting files used by multiple other applications. This is the data component of the ACN Monitoring Common app and contains all the Splunk knowledge objects for the Splunk indexer.   |


## 3. Constraints ##

### Host Investigation Dashboard ###
The **Host Investigation** dashboard is intended for System Administrators. Note that it is expected that Splunk accounts viewing the dashboard have a minimum of power user permissions. This is due to the default concurrent search limit Splunk users have. The dashboard has a large number of concurrent searches required to run in order to load the dashboard. Users will still be able to use the dashboard but it will take a long time to load. Alternatively, Splunk user permissions can be reconfigured to increase the number of concurrent searches they can run.

### Database Transaction Dashboard ###
This dashboard only monitors MSSQL databases running on Windows systems.
